import chromadb
from chromadb.config import Settings as ChromaSettings
import pandas as pd
import pickle
from app.config import get_settings
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

settings = get_settings()

class VectorStore:
    def __init__(self):
        chroma_settings = ChromaSettings(
            anonymized_telemetry=False,
            allow_reset=True,
            is_persistent=True
        )
        
        self.client = chromadb.PersistentClient(
            path=settings.CHROMA_PERSIST_DIRECTORY,
            settings=chroma_settings
        )
        
        self.collection = self._get_or_create_collection()

    def _get_or_create_collection(self):
        try:
            return self.client.get_collection("smartstore_faq")
        except:
            logger.info("Creating new collection 'smartstore_faq'")
            return self.client.create_collection("smartstore_faq")

    def load_and_index_data(self):
        logger.info("Starting to load FAQ data...")
        try:
            with open("data/final_result.pkl", "rb") as f:
                faq_data = pickle.load(f)
            
            questions = []
            answers = []
            for i, (question, answer) in enumerate(faq_data.items()):
                questions.append(question)
                answers.append(answer)
            
            logger.info(f"Loaded {len(questions)} FAQ pairs")
            
            self.collection.add(
                documents=answers,
                metadatas=[{"question": q} for q in questions],
                ids=[str(i) for i in range(len(questions))]
            )
            
            logger.info("FAQ data successfully indexed in ChromaDB")
        except Exception as e:
            logger.error(f"Error loading FAQ data: {str(e)}")
            raise

    def query_similar(self, query: str, n_results: int = 3):
        logger.info(f"Querying similar FAQs for: {query}")
        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=n_results
            )
            logger.info(f"Found {len(results['documents'][0])} similar FAQs")
            logger.info(f"Similar questions: {[meta['question'] for meta in results['metadatas'][0]]}")
            return results
        except Exception as e:
            logger.error(f"Error querying similar FAQs: {str(e)}")
            raise