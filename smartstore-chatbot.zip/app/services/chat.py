from openai import OpenAI
from typing import List, Dict, Generator, Optional
import json
import asyncio
from app.config import get_settings
from app.database.vector_store import VectorStore
from app.models.chat import ChatMessage
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

settings = get_settings()
client = OpenAI(api_key=settings.OPENAI_API_KEY)
vector_store = VectorStore()

# 채팅 히스토리를 저장할 딕셔너리
chat_histories: Dict[str, List[ChatMessage]] = {}

def get_chat_history(session_id: str) -> List[ChatMessage]:
    return chat_histories.get(session_id, [])

def update_chat_history(session_id: str, message: ChatMessage):
    if session_id not in chat_histories:
        chat_histories[session_id] = []
    chat_histories[session_id].append(message)

def is_smartstore_related(query: str):
    system_prompt = """
    다음 질문이 네이버 스마트스토어와 관련이 있는지 판단해주세요.
    관련이 있다면 "yes: [설명]", 관련이 약간 있다면 "related: [제안]", 
    관련 없다면 "no"로만 답변해주세요.
    
    질문: {query}
    """.format(query=query)
    
    response = client.chat.completions.create(
        model=settings.MODEL_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query}
        ],
        temperature=0,
        max_tokens=50
    )
    
    return response.choices[0].message.content.strip()

async def generate_follow_up_question(context: str, previous_answer: Optional[str] = None) -> str:
    try:
        prompt = """
        주어진 대화 맥락을 바탕으로, 사용자가 추가로 궁금해할 만한 자연스러운 후속 질문을 1개만 생성해주세요.
        질문은 한국어로 작성해주시고, 구체적이고 실용적이어야 합니다.
        
        이전 질문: {context}
        이전 답변: {answer}
        """.format(context=context, answer=previous_answer if previous_answer else "")
        
        response = await asyncio.to_thread(
            client.chat.completions.create,
            model=settings.MODEL_NAME,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=100
        )
        
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Error in generate_follow_up_question: {str(e)}")
        return "추가 질문이 필요하신가요?"
    
async def chat_stream(query: str, session_id: str):
    logger.info(f"Starting chat stream for query: {query}")
    try:
        # FAQ 검색
        logger.info("Querying similar FAQs")
        similar_faqs = vector_store.query_similar(query)
        
        # 유사한 FAQ 로그
        similar_questions = [meta['question'] for meta in similar_faqs['metadatas'][0]]
        similar_answers = similar_faqs['documents'][0]
        logger.info(f"Similar questions found: {similar_questions}")
        logger.info(f"Similar answers found: {similar_answers}")
        
        # 시스템 프롬프트에 FAQ 정보 직접 포함
        system_prompt = f"""
        당신은 네이버 스마트스토어 FAQ 챗봇입니다. 다음 가이드라인을 준수하세요:

        1. 제공된 FAQ 정보를 기반으로 정확하고 친절하게 답변하세요.

        2. 답변이 완료된 후 반드시 추가로 궁금해할 만한 관련 질문을 제안합니다.

        3. 후속 질문 제안 규칙:
        - 현재 대화의 맥락과 직접적으로 연관됨
        - 사용자에게 실질적으로 도움이 되는 추가 정보
        - 간결하고 명확한 형식
        - 최대 2-3개의 후속 질문 제안
        - 질문 형식: "- [구체적이고 유용한 후속 질문]"

        4. 예시:
        - 미성년자 판매 회원 등록 불가능에 대한 답변 후:
        - 등록에 필요한 서류가 궁금하신가요?
        - 성인 보호자를 통한 입점 방법이 궁금하신가요?

        제공된 FAQ 정보:
        {json.dumps(similar_faqs, ensure_ascii=False)}
        """
        
        # 대화 기록 준비
        history = get_chat_history(session_id)
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query}
        ]
        
        # OpenAI API 호출
        completion = client.chat.completions.create(
            model=settings.MODEL_NAME,
            messages=messages,
            temperature=settings.TEMPERATURE,
            max_tokens=settings.MAX_TOKENS,
            stream=True
        )

        collected_message = []
        
        for chunk in completion:
            if hasattr(chunk.choices[0].delta, 'content') and chunk.choices[0].delta.content:
                content = chunk.choices[0].delta.content
                collected_message.append(content)
                yield {
                    "type": "message",
                    "content": content
                }

        full_response = ''.join(collected_message)
        
        # 채팅 히스토리 업데이트
        update_chat_history(session_id, ChatMessage(role="user", content=query))
        update_chat_history(session_id, ChatMessage(role="assistant", content=full_response))

        # 명시적 종료 이벤트
        yield {
            "type": "end",
            "content": ""
        }

    except Exception as e:
        logger.error(f"Error in chat_stream: {str(e)}")
        yield {
            "type": "error",
            "content": f"오류가 발생했습니다: {str(e)}"
        }
        yield {
            "type": "end",
            "content": ""
        }
